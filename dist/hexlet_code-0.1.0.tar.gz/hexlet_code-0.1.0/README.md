### Hexlet tests and linter status:
[![Actions Status](https://github.com/anastasiia-nez/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/anastasiia-nez/python-project-49/actions)

### Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/d8cb7553b2ceef7c8dd2/maintainability)](https://codeclimate.com/github/anastasiia-nez/python-project-49/maintainability)
